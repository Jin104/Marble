#pragma once

void BonusEvent(int i);
void StartEvent(int i);
void IslandEvent(int i);
void OlympicEvent(int i);
void WorldTourEvent(int i);
void TaxEvent(int i);