#pragma once

void Bankrupt(int turn, int price);
int SellBuilding(int turn, int price);

void TouristMonop(int turn);
void ColorMonop(int turn);
void LineMonop(int turn);

void CheckGameOver(int turn);