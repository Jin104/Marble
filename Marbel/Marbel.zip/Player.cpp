#include "player.h"
#include "draw.h"


LinkedList *NewList() {

	LinkedList *list = (LinkedList*)malloc(sizeof(LinkedList));
	list->head = NULL;
	list->tail = NULL;

	list->size = 0;

	return list;
}

Node *NewNode(char *local, int price, int num) {
	Node *node = (Node*)malloc(sizeof(Node));
	strcpy(node->local, local);
	node->price = price;
	node->num = num;
	node->next = NULL;
	return node;
}

void HangNode(LinkedList *list, Node *node) {

	if (list->head == NULL) {
		list->head = node;
		list->tail = node;
		list->size++;
		return;
	}
	
	Node *pos = list->head;

	while (pos->next != NULL) {
		pos = pos->next;
	}

	node->prev = pos;
	node->next = pos->next;

	pos->next = node;
	pos->next->prev = node;

	list->size++;

	//while (pos->next != NULL && pos->num < node->num) {
	//	pos = pos->next;
	//}
	//if (list->head == pos) {
	//	node->next = pos;
	//	pos->prev = node;
	//	list->head = node;
	//}/*
	//else if (pos->next == NULL) {
	//	node->prev = pos->prev;
	//	pos->prev->next = node;
	//	list->tail = node;
	//
	//}*/
	//else {
	//	node->prev = pos;
	//	node->next = pos->next;

	//	pos->next = node;
	//	pos->next->prev = node;
	//}
	
	list->size++;
}

//
//void Erase(LinkedList *list, Node *pos) {
//	DisconnectNode(pos);
//	free(pos);
//	list->size--;
//}
//
//void DisconnectNode(Node *pos) {
//	if (pos == NULL) {
//		return;
//	}
//	pos->prev->next = pos->next;
//	pos->next->prev = pos->prev;
//}

void PrintList(LinkedList *list) {
	Node *prev, *pos;
	prev = pos = list->head;
	int i = 1;
	while (pos != NULL) {
		gotoxy(110, i);
		printf("%d %s %d\n", pos->num, pos->local,pos->price);
		pos = pos->next;
		i++;
	}
}

void PrintList2(LinkedList *list) {
	Node *prev, *pos;
	prev = pos = list->head;
	int i = 20;
	while (pos != NULL) {
		gotoxy(110, i);
		printf("%d %s %d", pos->num, pos->local, pos->price);
		pos = pos->next;
		i++;
	}
}

Node *FindNode(LinkedList *list, char *local) {
	Node *temp;
	temp = list->head;
	while (temp != NULL) {
		if (strcmp(temp->local, local) == 0) {
			return temp;
		}
		else {
			temp = temp->next;
		}
	}
	printf("�������� �ʽ��ϴ�.\n");
	return temp;
}

void modifiNode(LinkedList *list, char *local, int price) {
	Node *node = FindNode(list, local);
	node->price = price;
}